import React from "react";
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import Index from './components/index';
import Reports from './components/reports/reports';
import Graphs from './components/graphs';

function AppRouter() {
  return (
    <Router>
        <Route path="/" exact component={Index} />
        <Route path="/reports/" component={Reports} />
        <Route path="/graphs/" component={Graphs} />
    </Router>
  );
}

export default AppRouter;