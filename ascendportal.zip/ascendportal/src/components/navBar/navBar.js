import React, { Component } from "react";
import navbar from './navBar.css';
import { Link } from "react-router-dom";
import 'font-awesome/css/font-awesome.min.css';

export default class NavBar extends Component {
    constructor(props) {
        super(props);
        this.state = {
            liActive : true,
            iconsShow : true
        }
        this.handleClick = this.handleClick.bind(this);
    }

    handleClick() {
        this.setState({
            liActive: !this.state.liActive,
            iconsShow: !this.state.iconsShow
        });
      }

    render() {
        return (
            <div>
                <div id="hBar">
                    <ul>
                        <li onClick={ this.handleClick } className= { this.state.liActive ? "li-active" : "button" }><img src="favicon.ico" /></li>
                    </ul>
                </div>
                <div id="vBar">
                    <ul className= { this.state.liActive ? "li-active" : "button" }>
                        <li><Link to="/"><span className= { this.state.liActive ? "show" : "hide" }>Home</span> <span><i class="fa fa-home" aria-hidden="true"></i></span></Link></li>
                        <li><Link to="/reports"><span className= { this.state.liActive ? "show" : "hide" }> reports </span> <span ><i class="fa fa-home" aria-hidden="true"></i></span></Link></li>
                        <li><Link to="/graphs"><span className= { this.state.liActive ? "show" : "hide" }> Graphs </span> <span><i class="fa fa-home" aria-hidden="true"></i></span></Link></li>
                    </ul>
                </div>
            </div>
        )
    }
}