import React, { Component } from "react";
import reportsTable from './reportsTable.css';
import axios from 'axios';

export default class ReportsTable extends Component {
    state = {
        persons: []
    }

    componentDidMount() {
        axios.get(`https://jsonplaceholder.typicode.com/users`)
            .then(res => {
                const persons = res.data;
                this.setState({ persons });
            })
    }

    render() {
        return (
            <div>
                <h2>Users Table</h2>
                <table>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>UserName</th>
                        <th>Email</th>
                    </tr>
                    {this.state.persons.map(person => 
                        <tr>
                        <td>{person.id}</td>
                        <td>{person.name}</td>
                        <td>{person.username}</td>
                        <td>{person.email}</td>
                    </tr>
                    )}
                    
                </table>
            </div>
        )
    }
}