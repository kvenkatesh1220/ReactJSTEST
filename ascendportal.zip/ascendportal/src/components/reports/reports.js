import React, { Component } from "react";
import reports from './reports.css';
import NavBar from '../navBar/navBar';
import ReportsTable from './reportsTable'

export default class Reports extends Component {

    render() {
        return (
            <div className="container">
                <div className="row">
                    <div className="col-lg-4">
                        <NavBar />
                    </div>
                    <div className="col-lg-8 render-area">
                        <ReportsTable />
                    </div>
                </div>
            </div>
        )
    }
}