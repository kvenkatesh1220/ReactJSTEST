import React, { Component } from "react";

export default class Graphs extends Component {

    render() {
        return (
            <div >
                In Graphs File
            </div>
        )
    }
}