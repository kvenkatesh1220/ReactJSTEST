import React, { Component } from "react";
import NavBar from '../navBar/navBar';
import Graphs from './graphs';

export default class Reports extends Component {

    render() {
        return (
            <div className="container">
                <div className="row">
                    <div className="col-lg-4">
                        <NavBar />
                    </div>
                    <div className="col-lg-8 render-area">
                        <Graphs />
                        
                    </div>
                </div>
            </div>
        )
    }
}